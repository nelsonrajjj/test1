#crs-1
docker node update --label-add cassandra=1 kzn2do5azuga022gcd5h72mpm
docker node update --label-add rest=1 kzn2do5azuga022gcd5h72mpm
docker node update --label-add shadow=any kzn2do5azuga022gcd5h72mpm

docker node update --label-add cassandra=2 ua0cjx3d3zr9qh31u4ih3l2yx
docker node update --label-add rest=2 ua0cjx3d3zr9qh31u4ih3l2yx
docker node update --label-add shadow=any ua0cjx3d3zr9qh31u4ih3l2yx

docker node update --label-add cassandra=3 fbhkjzc9ko49q7xgl0g621pmk
docker node update --label-add rest=3 fbhkjzc9ko49q7xgl0g621pmk
docker node update --label-add shadow=any fbhkjzc9ko49q7xgl0g621pmk

#docker node update --label-add zookeeper=1 kkskxlgikbz04o3ji82kvqaa7
#docker node update --label-add kafka=1 kkskxlgikbz04o3ji82kvqaa7
#docker node update --label-add emqtt=1 kkskxlgikbz04o3ji82kvqaa7
#docker node update --label-add bridge=1 kkskxlgikbz04o3ji82kvqaa7
#docker node update --label-add web=1 kkskxlgikbz04o3ji82kvqaa7
docker node update --label-add inserter=any kkskxlgikbz04o3ji82kvqaa7
docker node update --label-add erm=any kkskxlgikbz04o3ji82kvqaa7
docker node update --label-add aggregator=any kkskxlgikbz04o3ji82kvqaa7
docker node update --label-add flink_aggregator=any kkskxlgikbz04o3ji82kvqaa7
docker node update --label-add flink_erm=any kkskxlgikbz04o3ji82kvqaa7

#docker node update --label-add zookeeper=2 4n27kzp681wavdl1u9jomvpg0
#docker node update --label-add kafka=2 4n27kzp681wavdl1u9jomvpg0
#docker node update --label-add emqtt=2 4n27kzp681wavdl1u9jomvpg0
#docker node update --label-add bridge=2 4n27kzp681wavdl1u9jomvpg0
#docker node update --label-add web=2 4n27kzp681wavdl1u9jomvpg0
docker node update --label-add inserter=any 4n27kzp681wavdl1u9jomvpg0
docker node update --label-add erm=any 4n27kzp681wavdl1u9jomvpg0
docker node update --label-add aggregator=any 4n27kzp681wavdl1u9jomvpg0
docker node update --label-add flink_aggregator=any 4n27kzp681wavdl1u9jomvpg0
docker node update --label-add flink_erm=any 4n27kzp681wavdl1u9jomvpg0

