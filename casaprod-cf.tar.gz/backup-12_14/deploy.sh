#!/bin/bash
export SECRETS_VERSION=1

docker stack deploy --with-registry-auth swarm --compose-file "$1"
