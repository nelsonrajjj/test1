#!/usr/bin/env python3

from string import Template

#CONFIG Variables
TOTAL_MBW=2
TOTAL_CRS=3
TOTAL_KFE=2

HEADERS="""version: '3.7'
services:
"""

REST_IMAGE="rest-service_provider:1.2.0-22-g8bc3308@sha256:f2488f0ec3ae1e437092300b730952adddc3e7589d7cb85e2d58dbc51a75da4e"
SHADOW_IMAGE="shadow-service_provider:1.2.0-7-gc6e17c9@sha256:5f4878146a0b22fd93f10f10712fefaf3b0a299a004fc13c77b6f6aa8023d5d8"
WEB_IMAGE="web-service_provider:2.1.0-56-g0203f46@sha256:cd697253e4c8d60013f6a74f281f190e5b597d882305d8d4f8e3f8709d0f262f"
BRIDGE_IMAGE="bridge-service_provider:1.1.5-1242-g121c865@sha256:b7384384bcdf5aef8db260c85d1a38e15e34ec965d5ae9ab75da70a5ce2c5ce7"
INSERTER_IMAGE="web-service_provider:2.1.0-56-g0203f46@sha256:cd697253e4c8d60013f6a74f281f190e5b597d882305d8d4f8e3f8709d0f262f"
AGGREGATOR_IMAGE="flink_aggregator-master:6.0-6-g7b6bd73@sha256:eba7f1abb225cfade4e4b3710c23035ca5cec7099a4b0ff10e833765612dca76"
FLINK_ERM_IMAGE="flink_erm-master:6.0-6-g7b6bd73@sha256:44b387b95834c5c5208977c6eaf9a428fd34ad5c1b75092cc2f50e711c48f194"
ERM_IMAGE="web-service_provider:2.1.0-56-g0203f46@sha256:cd697253e4c8d60013f6a74f281f190e5b597d882305d8d4f8e3f8709d0f262f@sha256:747e87923ac4a10dc9218e82d1b1e10a2638c68a151356b9e21a466b4afc94d7"

#Define the server classes
class server:

    def write(self, index, data):
        self.write_file(self.name.format(index), data)
        
    def write_scaled(self, data):
        self.write_file(self.name, data)

    def write_file(self, name, data):
        with open(name + ".yml","w+") as f:
            f.write(HEADERS)
            f.write(data)
            
class emqtt(server):
    name = 'emqtt{:d}'
    template = """ 
 emqtt$index:
  image: localhost:5000/emqttd-v3.0.1:latest
  ports:
   - target: 1883
     published: $insecure_port
     protocol: tcp
     mode: host
   - target: 8883
     published: $secure_port
     protocol: tcp
     mode: host
  deploy:
   placement:
    constraints:
     - node.labels.emqtt == $server_index

"""

    def __init__(self, total_mbw):
        self.total_mbw = total_mbw
        
    def write_all(self):
        # Make 3 emqtt servers per server
        for server in range(1, self.total_mbw + 1):
            for mqtt_index in range(0, 3):
                index = 1 + ((server - 1) * 3) + mqtt_index
                sub_dict = dict(server_index=server, index = index, insecure_port = 1883 + mqtt_index, secure_port = 8883 + mqtt_index)
                server_string = Template(self.template).substitute(sub_dict)
                self.write(index, server_string)

class bridge(server):
    name = "bridge{:d}"
    template = """  
 bridge$index:
  image: localhost:5000/bridge-service_provider:1.1.5-1241-g2c501c9
  environment:
   - MQTT_HOST_NAME=tcp://$mqtt_ip:$insecure_port
   - KAFKA_HOST_NAME=kafka$kafka_index:9092
   - ZK_HOST_NAME=zookeeper$zookeeper_index:2181
  logging:
   options:
    max-size: "100m"
    max-file: "3"
  deploy:
   placement:
    constraints:
     - node.labels.bridge == $server_index

"""
    


    def __init__(self, total_mbw, total_kfe):
        self.total_mbw = total_mbw
        self.total_kfe = total_kfe
        
    def write_all(self):
        #Figure out the zookeeper servers
        zookeeper_count = 3
        # if self.total_kfe < 3:
        #     zookeeper_count = self.total_kfe - 1 + (self.total_kfe % 2)
        
        # Make 1 bridge per eMQTT server
        kafka_index = 1
        zookeeper_index = 1
        for server in range(1, self.total_mbw + 1):
            for mqtt_index in range(0, 3):
                index = 1 + ((server - 1) * 3) + mqtt_index
                mqtt_ip = 'emqtt' + str(index)
                sub_dict = dict(server_index=server, index = index, insecure_port = 1883, kafka_index= kafka_index,zookeeper_index = zookeeper_index, mqtt_ip = mqtt_ip )
                server_string = Template(self.template).substitute(sub_dict)
                self.write(index, server_string)
                kafka_index = ((kafka_index + 1))
                if kafka_index > self.total_kfe:
                    kafka_index = 1
                zookeeper_index = ((zookeeper_index + 1))
                if zookeeper_index > zookeeper_count:
                    zookeeper_index = 1

class cassandra(server):
    name = "cassandra{:d}"
    template = """  
 cassandra$server_index:
  image: localhost:5000/embedur_cassandra:3.11
  volumes:
   - /data/cassandra:/var/lib/cassandra
  environment:
   - CASSANDRA_CLUSTER_NAME="Production Cluster"
   - CASSANDRA_SEEDS=$seeds
  deploy:
   placement:
    constraints:
     - node.labels.cassandra == $server_index

"""

    def __init__(self, total_crs):
        self.total_crs = total_crs
        
    def write_all(self):

        #get seeds
        seed_count = 3
        seeds = ''
        if self.total_crs < 3:
            seed_count = self.total_crs
        for seed in range(1, seed_count + 1):
            if seed > 1:
                seeds = seeds + ","
            seeds = seeds + "tasks.cassandra" + str(seed)
            
        for server in range(1, self.total_crs + 1):
            sub_dict = dict(server_index=server, seeds=seeds)
            server_string = Template(self.template).substitute(sub_dict)
            self.write(server, server_string)


class zookeeper(server):
    name = "zookeeper{:d}"
    template = """
 zookeeper$server:
  image: localhost:5000/zookeeper:3.4.13
  volumes:
   - /data/zookeeper/data:/data
   - /data/zookeeper/datalog:/datalog
  environment:
   - ZOO_STANDALONE_ENABLED=false
   - ZOO_MY_ID=$server
   - ZOO_SERVERS=$servers
  deploy:
   placement:
    constraints:
     - node.labels.zookeeper == $server

"""

    def __init__(self, total_kfe):
        self.total_kfe = total_kfe
        
    def write_all(self):
        #Figure out the zookeeper servers
        zookeeper_count = 3
        # if self.total_kfe < 3:
        #     zookeeper_count = self.total_kfe - 1 + (self.total_kfe % 2)

        for server in range(1, zookeeper_count + 1):
            zoo_server_string = ''
            for zoo_server in range(1, zookeeper_count + 1):
                if zoo_server is server:
                    zoo_server_string = zoo_server_string + ' server.' + str(zoo_server) + '=0.0.0.0:2888:3888'
                else:
                    zoo_server_string = zoo_server_string + ' server.' + str(zoo_server) + '=zookeeper' + str(zoo_server) + ':2888:3888'
        
            sub_dict = dict(server=server, servers=zoo_server_string)
            server_string = Template(self.template).substitute(sub_dict)
            self.write(server, server_string)

class kafka(server):
    name = "kafka{:d}"
    template = """
 kafka$server:
  image: localhost:5000/kafka:2.12-2.2.0
  volumes:
   - /data/kafka:/kafka
  environment:
   KAFKA_ZOOKEEPER_CONNECT: $zookeepers
   KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: INSIDE:PLAINTEXT
   KAFKA_LOG_DIRS: /kafka/kafka-logs/
   KAFKA_ADVERTISED_LISTENERS: INSIDE://kafka$server:9092
   KAFKA_LISTENERS: INSIDE://:9092
   KAFKA_INTER_BROKER_LISTENER_NAME: INSIDE
   KAFKA_BROKER_ID: $server
   KAFKA_AUTO_CREATE_TOPICS_ENABLE: "false"
  deploy:
   placement:
    constraints:
     - node.labels.kafka == $server

"""

    def __init__(self, total_kfe, total_crs):
        self.total_kfe = total_kfe
        self.total_crs = total_crs
        
    def write_all(self):
        #Figure out the zookeeper servers
        zookeeper_count = 3
        zookeepers = ''
        # if self.total_kfe < 3:
        #     zookeeper_count = self.total_kfe - 1 + (self.total_kfe % 2)

        for zookeeper in range(1, zookeeper_count + 1):
            if zookeeper > 1:
                zookeepers = zookeepers + ","
            zookeepers = zookeepers + "zookeeper" + str(zookeeper) + ':2181'

        for server in range(1, self.total_kfe + 1):
            sub_dict = dict(server=server, zookeepers=zookeepers, half=(self.total_kfe / 2) + 1,third=(self.total_kfe / 3) + 1,fourth=(self.total_kfe / 4) + 1,fifth=(self.total_kfe / 5) + 1,tenth=(self.total_kfe / 10) + 1, shadow_count=self.total_crs )
            server_string = Template(self.template).substitute(sub_dict)
            self.write(server, server_string)

class rest(server):
    name = "rest{:d}"
    template = """
 rest$server:
  image: localhost:5000/$image
  ports:
     - target: 443
       published: 443
       protocol: tcp
       mode: host
     - target: 80
       published: 80
       protocol: tcp
       mode: host
  volumes:
   - /home/ubuntu/shared/:/opt/app/host/
  environment:
   - HOST_DIR=/opt/app/host
   - PROVISION_DIR=/opt/app/host
   - CASSANDRA_HOST_NAME=$cassandra_nodes
   - KAFKA_HOST_NAME=$kafkas
   - MQTT_HOST_NAME=$emqtts
   - PORT=80
   - SSL_PORT=443
   - WIFI_ANALYTICS=1
   - MULTI_TENANCY=1
   - DEFAULT_PROVIDER=Default
   - LOG_LEVEL=info
   - MESH_PROVISIONING=1
   - MESH_ENABLED=1
   - WEB_VERSION_FILE=/opt/app/host/web_version
   $initialize_db
  logging:
   options:
    max-size: "100m"
    max-file: "3"
  deploy:
     placement:
      constraints:
       - node.labels.rest == $server

"""

    def __init__(self, total_crs, total_kfe, total_mbw):
        self.total_kfe = total_kfe
        self.total_crs = total_crs
        self.total_mbw = total_mbw
        
    def write_all(self):
        servers=''

        #figure out cassandra servers
        cassandra_nodes = ''
        for cassandra in range(1, self.total_crs + 1):
            if cassandra > 1:
                cassandra_nodes = cassandra_nodes + ','
            cassandra_nodes = cassandra_nodes + 'cassandra' + str(cassandra)
        

        #figure out kafka servers
        kafka_nodes = ''
        for kafka in range(1, self.total_kfe + 1):
            if kafka > 1:
                kafka_nodes = kafka_nodes + ','
            kafka_nodes = kafka_nodes + 'kafka' + str(kafka) + ':9092'
        
        #Figure out the emqtt servers
        emqtt_servers = ''
        for emqtt_server in range(1, (self.total_mbw * 3) + 1):
            if emqtt_server > 1:
                emqtt_servers = emqtt_servers + ','
            emqtt_servers = emqtt_servers + 'emqtt' + str(emqtt_server) + ':1883'
        
        for server in range(1, self.total_crs + 1):
            if server is 1:
                sub_dict = dict(server=server, kafkas=kafka_nodes, cassandra_nodes = cassandra_nodes, emqtts = emqtt_servers, initialize_db = '- INITIALIZE_DB=1', image=REST_IMAGE)
            else:
                sub_dict = dict(server=server, kafkas=kafka_nodes, cassandra_nodes = cassandra_nodes, emqtts = emqtt_servers, initialize_db = '', image=REST_IMAGE )
            server_string = Template(self.template).substitute(sub_dict)
            self.write(server, server_string)
            
class shadow(server):
    name = "shadow"
    template = """
 shadow:
  image: localhost:5000/$image
  environment:
   - CASSANDRA_HOST_NAME=$cassandra_nodes
   - KAFKA_HOST_NAME=$kafkas
   - MQTT_HOST_NAME=$emqtts
   - AUTO_PROVISION_BY_GW_MAC=1
   - LOG_LEVEL=info
   - DEFAULT_PROVIDER=Default
   - WIFI_ANALYTICS=1
   - MESH_PROVISIONING=1
   - MESH_ENABLED=1
   - MULTI_TENANCY=1
  logging:
   options:
    max-size: "100m"
    max-file: "3"
  deploy:
   mode: replicated
   replicas: $servers
   placement:
    constraints:
     - node.labels.shadow == any

"""

    def __init__(self, total_crs, total_kfe, total_mbw):
        self.total_kfe = total_kfe
        self.total_crs = total_crs
        self.total_mbw = total_mbw
        
    def write_all(self):
        #figure out cassandra servers
        cassandra_nodes = ''
        for cassandra in range(1, self.total_crs + 1):
            if cassandra > 1:
                cassandra_nodes = cassandra_nodes + ','
            cassandra_nodes = cassandra_nodes + 'cassandra' + str(cassandra)
        
        #figure out kafka servers
        kafka_nodes = ''
        for kafka in range(1, self.total_kfe + 1):
            if kafka > 1:
                kafka_nodes = kafka_nodes + ','
            kafka_nodes = kafka_nodes + 'kafka' + str(kafka) + ':9092'

        #Figure out the emqtt servers
        emqtt_servers = ''
        for emqtt_server in range(1, (self.total_mbw * 3) + 1):
            if emqtt_server > 1:
                emqtt_servers = emqtt_servers + ','
            emqtt_servers = emqtt_servers + 'emqtt' + str(emqtt_server) + ':1883'
        
        sub_dict = dict(servers=self.total_crs, kafkas=kafka_nodes, cassandra_nodes = cassandra_nodes, emqtts = emqtt_servers,image=SHADOW_IMAGE)
        server_string = Template(self.template).substitute(sub_dict)
        self.write_scaled(server_string)
        
    
class web(server):
    name = "web"
    template = """
 web$server:
  image: localhost:5000/$image
  ports:
   - target: 443
     published: 443
     protocol: tcp
     mode: host
   - target: 80
     published: 80
     protocol: tcp
     mode: host
  volumes:
   - /home/ubuntu/sharded/:/opt/app/host
  environment:
   - REST_HOST_NAME=https://rest.wifi-analytics.singnet.com.sg
   - SSL_KEY_FILE=/opt/app/www/certs/cloud.key
   - SSL_CERT_FILE=/opt/app/www/certs/cloud.pem
   - FORCE_REDIRECT_TO_HTTPS=1
   - PORT=80
   - SSL_PORT=443
   - WIFI_ANALYTICS=1
   - MULTI_TENANCY=1
   - DEFAULT_THEME=netcomm
   - BRAND=netcomm
   - TITLE=NetComm
   - FAVICON=assets/icons/netcomm_favicon.ico
   - LOG_LEVEL=info
  logging:
   options:
    max-size: "100m"
    max-file: "3"
  deploy:
     placement:
       constraints:
         - node.labels.web == any

"""
    def __init__(self, total_mbw):
        self.total_mbw = total_mbw
        
    def write_all(self):
        servers=''

        for server in range(1, self.total_mbw + 1):
            sub_dict = dict(server=server,image=WEB_IMAGE)
            server_string = Template(self.template).substitute(sub_dict)
            self.write_scaled(server_string)

class erm(server):
    name = "erm"
    template = """
 erm:
  image: localhost:5000/$image
  volumes:
   - /home/ubuntu/shared/rest_key.jwt:/opt/app/erm.jwt
  environment:
   - KAFKA_HOST_NAME=$kafkas
   - REST_HOST_NAME=$rests
  logging:
   options:
    max-size: "100m"
    max-file: "3"
  deploy:
   mode: replicated
   replicas: $servers
   endpoint_mode: vip
   placement:
    constraints:
     - node.labels.erm == any
"""
    def __init__(self, total_kfe, total_crs, total_mbw):
        self.total_kfe = total_kfe
        self.total_crs = total_crs
        self.total_mbw = total_mbw
        
    def write_all(self):
        #figure out kafka servers
        kafka_nodes = ''
        for kafka in range(1, self.total_kfe + 1):
            if kafka > 1:
                kafka_nodes = kafka_nodes + ','
            kafka_nodes = kafka_nodes + 'kafka' + str(kafka)
        
        #Figure out the rest servers
        rests = ''
        for rest in range(1, self.total_crs + 1):
            if rest > 1:
                rests = rests + ','
            rests = rests + 'rest' + str(rest) 
        
        sub_dict = dict(servers=self.total_kfe / 2 + 1, rests=rests, kafkas = kafka_nodes,image=ERM_IMAGE)
        server_string = Template(self.template).substitute(sub_dict)
        self.write_scaled(server_string)


class inserters(server):
    name = "json_inserter"
    template = """
 json_inserter:
  image: localhost:5000/$image
  environment:
   CASSANDRA_HOST_NAME: $cassandra_nodes
   KAFKA_HOST_NAME=$kafka_servers
   LOG_LEVEL: info
  logging:
   options:
    max-size: "100m"
    max-file: "3"
  deploy:
   mode: replicated
   replicas: $servers
   placement:
    constraints:
     - node.labels.inserter == any
"""
    configs = []

    def __init__(self, total_kfe, total_crs, total_mbw):
        self.total_kfe = total_kfe
        self.total_crs = total_crs
        self.total_mbw = total_mbw

    def write_all(self):
        #figure out cassandra servers
        cassandra_nodes = ''
        for cassandra in range(1, self.total_crs + 1):
            if cassandra > 1:
                cassandra_nodes = cassandra_nodes + ','
            cassandra_nodes = cassandra_nodes + 'cassandra' + str(cassandra)
        
        #figure out kafka servers
        kafka_nodes = ''
        for kafka in range(1, self.total_kfe + 1):
            if kafka > 1:
                kafka_nodes = kafka_nodes + ','
            kafka_nodes = kafka_nodes + 'kafka' + str(kafka) + ':9092'
        
        server_count = self.total_kfe  * 2
        sub_dict = dict(kafka_servers=kafka_nodes, cassandra_nodes = cassandra_nodes, servers=server_count, image=INSERTER_IMAGE)
        server_string = Template(self.template).substitute(sub_dict)
        self.write_scaled(server_string)

    
class flink_aggregator(server):
    name = "flink_aggregator"
    template = """
 flink-aggregator:
  image: localhost:5000/$image
  logging:
   options:
    max-size: "100m"
    max-file: "3"
  environment:
   - CASSANDRA_IP=$cassandra_nodes
   - KAFKA_IP=$kafka_nodes
   - SCHEMA_TOPIC=json_schema
   - FLINK_PARALLELISM=$parallelism
   - FLINK_CLUSTER_IP=flink-aggregator
   - FLINK_HEAP_SIZE=$jobmanager_heap_size
   - KAFKA_TOPICS=devices.optRuntime,devices.optAggregation
  command: "job-cluster"
  deploy:
   placement:
    constraints:
     - node.labels.aggregator == any

 flink-aggregator-tm:
  image: localhost:5000/$image
  logging:
   options:
    max-size: "100m"
    max-file: "3"
  environment:
   - FLINK_CLUSTER_IP=flink-aggregator
   - FLINK_HEAP_SIZE=$taskmanager_heap_size
  command: "task-manager"
  deploy:
   mode: replicated
   replicas: $parallelism
   endpoint_mode: vip
   placement:
    constraints:
     - node.labels.flink_aggregator == any
"""

    def __init__(self, total_kfe, total_crs, total_mbw):
        self.total_kfe = total_kfe
        self.total_crs = total_crs
        self.total_mbw = total_mbw

    def write_all(self):
        #figure out cassandra servers
        cassandra_nodes = ''
        for cassandra in range(1, self.total_crs + 1):
            if cassandra > 1:
                cassandra_nodes = cassandra_nodes + ','
            cassandra_nodes = cassandra_nodes + 'cassandra' + str(cassandra)
        
       #figure out kafka servers
        kafka_nodes = ''
        for kafka in range(1, self.total_kfe + 1):
            if kafka > 1:
                kafka_nodes = kafka_nodes + ','
            kafka_nodes = kafka_nodes + 'kafka' + str(kafka) + ':9092'
            #kafka_nodes = kafka_nodes + '10.0.3.' + str(kafka) 
        
        parallelism = self.total_kfe
        version='master:4.0-17-ga898519'
        jobmanager_heap_size='4092m'
        taskmanager_heap_size='2048m'
        sub_dict = dict(cassandra_nodes=cassandra_nodes,kafka_nodes=kafka_nodes,jobmanager_heap_size=jobmanager_heap_size, image=AGGREGATOR_IMAGE,taskmanager_heap_size=taskmanager_heap_size, parallelism=parallelism)
        server_string = Template(self.template).substitute(sub_dict)
        self.write_scaled(server_string)

class flink_erm(server):
    name= "flink_erm"
    template= """
 flink-erm:
  image: localhost/$image
  volumes:
   - /home/ubuntu/shared/rest_key.jwt:/opt/flink/flink.jwt
  logging:
   options:
    max-size: "100m"
    max-file: "3"
  environment:
   - CASSANDRA_IP=$cassandra_nodes
   - KAFKA_IP=$kafka_nodes
   - SCHEMA_TOPIC=json_schema
   - REST_IP=$rest_servers
   - FLINK_PARALLELISM=$parallelism
   - FLINK_CLUSTER_IP=flink-erm
   - FLINK_HEAP_SIZE=$jobmanager_heap_size
  command: "job-cluster"
  deploy:
   placement:
    constraints:
     - node.labels.flink_erm == any

 flink-erm-tm:
  image: localhost:5000/$image
  volumes:
   - /home/ubuntu/shared/rest_key.jwt:/opt/flink/flink.jwt
  logging:
   options:
    max-size: "100m"
    max-file: "3"
  environment:
   - FLINK_CLUSTER_IP=flink-erm
   - FLINK_HEAP_SIZE=$taskmanager_heap_size
  command: "task-manager"
  deploy:
   mode: replicated
   replicas: $parallelism
   endpoint_mode: vip
   placement:
    constraints:
     - node.labels.flink_erm == any

"""
    def __init__(self, total_kfe, total_crs, total_mbw):
        self.total_kfe = total_kfe
        self.total_crs = total_crs
        self.total_mbw = total_mbw

    def write_all(self):
        #figure out cassandra servers
        cassandra_nodes = ''
        for cassandra in range(1, self.total_crs + 1):
            if cassandra > 1:
                cassandra_nodes = cassandra_nodes + ','
            cassandra_nodes = cassandra_nodes + 'cassandra' + str(cassandra)
        
        #Figure out the zookeeper servers
        zookeeper_count = 3
        zookeepers = ''
        # if self.total_kfe < 3:
        #     zookeeper_count = self.total_kfe - 1 + (self.total_kfe % 2)
 
       #figure out kafka servers
        kafka_nodes = ''
        for kafka in range(1, self.total_kfe + 1):
            if kafka > 1:
                kafka_nodes = kafka_nodes + ','
            kafka_nodes = kafka_nodes + 'kafka' + str(kafka) + ':9092'
            #kafka_nodes = kafka_nodes + '10.0.3.' + str(kafka) 
        
        #figure out the rest servers
        rest_servers = ''
        for rest in range(1, self.total_crs + 1):
            if rest > 1:
                rest_servers = rest_servers + ','
            rest_servers = rest_servers + 'http://rest' + str(rest) + ':80'

        servers = ''

        parallelism = self.total_kfe
        version='master:4.0-17-ga898519'
        jobmanager_heap_size='4092m'
        taskmanager_heap_size='2048m'
        sub_dict = dict(cassandra_nodes=cassandra_nodes,kafka_nodes=kafka_nodes,rest_servers=rest_servers,jobmanager_heap_size=jobmanager_heap_size, image=FLINK_ERM_IMAGE,taskmanager_heap_size=taskmanager_heap_size, parallelism=parallelism)
        server_string = Template(self.template).substitute(sub_dict)
        self.write_scaled(server_string)


m = emqtt(TOTAL_MBW)
b = bridge(TOTAL_MBW, TOTAL_KFE)
c = cassandra(TOTAL_CRS)
z = zookeeper(TOTAL_KFE)
k = kafka(TOTAL_KFE, TOTAL_CRS)
r = rest(TOTAL_CRS, TOTAL_KFE, TOTAL_MBW)
s = shadow(TOTAL_CRS, TOTAL_KFE, TOTAL_MBW)
w = web(TOTAL_MBW)
e = erm(TOTAL_KFE, TOTAL_CRS, TOTAL_MBW)
i = inserters(TOTAL_KFE, TOTAL_CRS, TOTAL_MBW)
a = flink_aggregator(TOTAL_KFE, TOTAL_CRS, TOTAL_MBW)
f = flink_erm(TOTAL_KFE, TOTAL_CRS, TOTAL_MBW)
m.write_all()
b.write_all()
c.write_all()
z.write_all()
k.write_all()
r.write_all()
s.write_all()
w.write_all()
e.write_all()
i.write_all()
a.write_all()
f.write_all()
