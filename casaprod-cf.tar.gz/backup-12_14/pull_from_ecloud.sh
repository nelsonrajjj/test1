#!/bin/bash
for i in `cat images`
do

ECLOUD="ecloud.embedur.com:5000/"
LOCAL="localhost:5000/"

docker pull "$ECLOUD$i"
docker tag "$ECLOUD$i" "$LOCAL$i"
docker push "$LOCAL$i"
done
