#!/bin/bash

while [ -z "$ID" ]
do
	    sleep .1
	        ID="$(docker ps | grep $1 | awk '{print $1}')"
	done
	shift
docker exec -u 0 -it $ID $@
