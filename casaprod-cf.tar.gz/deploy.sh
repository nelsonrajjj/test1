#!/bin/bash
export SECRETS_VERSION=2

docker stack deploy --with-registry-auth swarm --compose-file "$1"
