SOURCE=ecloud.embedur.com:5000
DIST=localhost:5000
for i in `cat image`
do
docker pull $SOURCE/$i
docker tag $SOURCE/$i $DIST/$i
docker push $DIST/$i
docker pull $DIST/$i
done

